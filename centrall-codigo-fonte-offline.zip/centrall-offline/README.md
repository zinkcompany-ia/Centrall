# Centrall — sistema operacional para agências

Centrall é um workspace operacional para centralizar o trabalho de uma agência em espaços, páginas, tarefas, decisões e processos. A primeira entrega implementa a Fase 1 do produto com uma interface em português do Brasil, navegação por árvore e abas, busca global, editor em blocos, tema claro/escuro e autenticação por convite preparada no servidor.

## Stack

- React + TypeScript + Vite
- Express + tRPC
- Drizzle ORM + banco MySQL-compatible gerenciado pelo WebDev
- Tailwind CSS 4 e CSS de produto em `client/src/index.css`
- JWT em cookie `httpOnly`, `Secure`, `SameSite=None` para o Preview HTTPS
- bcryptjs para hash de senhas

## Executar

```bash
pnpm install
pnpm db:migrate
pnpm dev
```

O servidor escuta a porta `3000` (ou a variável `PORT`) em `0.0.0.0`. O Preview requer o processo ativo nessa porta.

## Variáveis

O ambiente gerenciado fornece `DATABASE_URL` e `MANUS_JWT_SECRET`. Para execução local independente, é possível definir `DATABASE_URL` e `NEXORA_SESSION_SECRET`. A sessão usa o segredo gerenciado quando ele está disponível.

## Acesso de demonstração

No ambiente de desenvolvimento/Preview, o botão **Explorar demonstração** cria uma sessão de demonstração sem cadastro público. Em produção, esse atalho é bloqueado por padrão; convites continuam sendo o único caminho de criação de usuário. O login real aceita e-mail e senha de usuários convidados.

## Arquitetura

`client/src/App.tsx` contém o shell autenticado, Home, sidebar, árvore, abas, command palette e editor inicial. `server/routers.ts` concentra os procedimentos tRPC de autenticação, workspace, páginas e busca. `server/_core/nexoraAuth.ts` valida a sessão própria e aplica o cookie seguro. `drizzle/schema.ts` contém usuários, workspaces, membros, espaços, páginas, convites, sessões e auditoria.

A autorização é preparada para herança workspace → espaço → página, e todas as queries persistentes devem filtrar por `workspaceId`. O conteúdo de uma página é uma lista JSON ordenada de blocos para que imagens, embeds, comentários, colaboração e histórico possam ser adicionados sem migrar o editor inteiro.

## Fases

- **Fase 1 entregue:** autenticação, workspaces, espaços, árvore, abas, busca, Home, favoritos/recentes, split view e editor de blocos inicial.
- **Fase 2:** bancos de dados, propriedades, visualizações tabela/Kanban/calendário/Gantt/galeria e gráficos.
- **Fase 3:** colaboração em tempo real com presença, comentários, menções, notificações e histórico.
- **Fase 4:** módulos empresariais, automações, exportações, storage, lixeira de 30 dias e polimento de produção.

## Qualidade

```bash
pnpm check
pnpm test
pnpm build
```

A rota `/api/health` retorna o estado do serviço e `public/manus-routes.json` declara as rotas do Preview.
