export default {
  logoUrl: "https://dummyimage.com/256x256/0e7490/ffffff.png&text=N",
};
