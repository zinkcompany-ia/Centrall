/**
 * Banco de dados local do Centrall (modo offline).
 * Substitui o servidor Express/tRPC + MySQL. Todos os dados ficam no
 * IndexedDB do próprio aparelho — nada é enviado para a internet.
 */

type Block = { id: string; type: string; content?: string; checked?: boolean; language?: string };

type LocalUser = {
  id: number;
  openId: string;
  name: string;
  email: string;
  loginMethod: string;
  role: "admin" | "user";
  status: "active";
  salt: string | null;
  passwordHash: string | null;
  createdAt: string;
  lastSignedIn: string;
};

type LocalPage = {
  id: number;
  spaceId: number;
  parentId: number | null;
  title: string;
  icon: string;
  color: string;
  type: string;
  updatedAt: string;
  excerpt: string;
  content: Block[];
};

type LocalSpace = { id: number; name: string; icon: string; color: string; isPersonal: boolean };
type LocalWorkspace = { id: number; slug: string; name: string; initials: string; accentColor: string };
type UserData = { workspace: LocalWorkspace; spaces: LocalSpace[]; pages: LocalPage[]; isDemo: boolean };

type State = {
  version: 1;
  nextId: number;
  session: number | null;
  users: LocalUser[];
  data: Record<string, UserData>;
};

const DB_NAME = "centrall-offline";
const STORE = "kv";
const KEY = "state";
const DEMO_ID = -1;
const DEMO_EMAIL = "demo@centrall.local";
const DEMO_PASSWORD = "Nexora2026!";

/* ---------- IndexedDB (armazenamento) ---------- */

function openIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Não foi possível abrir o banco de dados local."));
  });
}

async function idbGet(): Promise<State | undefined> {
  const db = await openIdb();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE, "readonly").objectStore(STORE).get(KEY);
    request.onsuccess = () => resolve(request.result as State | undefined);
    request.onerror = () => reject(request.error);
  });
}

async function idbPut(state: State): Promise<void> {
  const db = await openIdb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(JSON.parse(JSON.stringify(state)), KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("Não foi possível salvar os dados."));
    tx.onabort = () => reject(tx.error ?? new Error("Não foi possível salvar os dados."));
  });
}

let statePromise: Promise<State> | null = null;

function emptyState(): State {
  return { version: 1, nextId: 1, session: null, users: [], data: {} };
}

function getState(): Promise<State> {
  if (!statePromise) {
    statePromise = idbGet().then(saved => saved ?? emptyState());
    // Pede ao navegador para não apagar os dados automaticamente quando faltar espaço.
    void navigator.storage?.persist?.().catch(() => undefined);
  }
  return statePromise;
}

async function save(state: State) {
  await idbPut(state);
}

/* ---------- Senhas (PBKDF2 via WebCrypto) ---------- */

const toHex = (buffer: ArrayBuffer) => Array.from(new Uint8Array(buffer)).map(b => b.toString(16).padStart(2, "0")).join("");

async function hashPassword(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: 120_000, hash: "SHA-256" }, key, 256);
  return toHex(bits);
}

const newSalt = () => toHex(crypto.getRandomValues(new Uint8Array(16)).buffer);

/* ---------- Dados iniciais ---------- */

function nowLabel() {
  return `Hoje, ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
}

const slugify = (value: string) =>
  value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70);

function seedWorkspace(opts: { workspaceName: string; userName: string; isDemo: boolean }): UserData {
  const first = opts.userName.trim().split(/\s+/)[0] || "";
  const initials = opts.workspaceName.trim().split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase() || "CS";
  const spaces: LocalSpace[] = [
    { id: -11, name: "Início", icon: "⌂", color: "#0E7490", isPersonal: false },
    { id: -12, name: "Comercial", icon: "↗", color: "#D97706", isPersonal: false },
    { id: -13, name: "Operações", icon: "◒", color: "#7C3AED", isPersonal: false },
    { id: -14, name: "Pessoas", icon: "✦", color: "#DB2777", isPersonal: false },
    { id: -15, name: "Financeiro", icon: "⌁", color: "#059669", isPersonal: false },
    { id: -16, name: "Pessoal", icon: "○", color: "#64748B", isPersonal: true },
  ];
  const page = (id: number, spaceId: number, parentId: number | null, title: string, icon: string, color: string, type: string, excerpt: string, content?: Block[]): LocalPage => ({
    id, spaceId, parentId, title, icon, color, type, updatedAt: nowLabel(), excerpt,
    content: content ?? [{ id: `intro-${id}`, type: "heading", content: title }, { id: `copy-${id}`, type: "paragraph", content: excerpt }],
  });
  const wsName = opts.workspaceName;
  const pages: LocalPage[] = [
    page(-101, -11, null, "Visão geral", "⌂", "#0E7490", "home", `Tudo o que está acontecendo na ${wsName}, em um só lugar.`, [
      { id: "b1", type: "heading", content: first ? `Bom dia, ${first}` : "Bom dia" },
      { id: "b2", type: "paragraph", content: `Aqui está o pulso da ${wsName}. O trabalho importante, sem o ruído.` },
      { id: "b3", type: "callout", content: "Hoje é um bom dia para transformar intenção em movimento." },
    ]),
    page(-102, -11, null, "Comunicados", "◈", "#0E7490", "page", "Atualizações e decisões que movem a empresa."),
    page(-103, -12, null, "Pipeline comercial", "▱", "#D97706", "database", "Negócios ativos, próximos passos e forecast.", [
      { id: "b4", type: "heading", content: "Pipeline comercial" },
      { id: "b5", type: "paragraph", content: "Uma visão compartilhada do que está avançando, travando e pedindo atenção." },
    ]),
    page(-104, -12, null, "Playbook de vendas", "✎", "#D97706", "page", "O jeito de transformar conversas em clientes."),
    page(-105, -13, null, "Projetos em andamento", "◌", "#7C3AED", "database", "Sprints, responsáveis e marcos do trimestre.", [
      { id: "b6", type: "heading", content: "Projetos em andamento" },
      { id: "b7", type: "paragraph", content: "Sprints do trimestre com clareza sobre responsáveis, prazos e próximos passos." },
    ]),
    page(-106, -13, -105, "Ritual semanal", "◷", "#7C3AED", "page", "Pauta e próximos passos da operação."),
    page(-107, -14, null, "Onboarding de pessoas", "✦", "#DB2777", "page", "Uma chegada bem cuidada começa antes do primeiro dia."),
    page(-108, -15, null, "Orçamento Q4", "⌁", "#059669", "page", "Metas, projeções e compromissos financeiros."),
  ];
  return {
    isDemo: opts.isDemo,
    workspace: { id: -1, slug: slugify(wsName) || "workspace", name: wsName, initials, accentColor: "#0E7490" },
    spaces,
    pages,
  };
}

/* ---------- Helpers ---------- */

const fail = (message: string): never => { throw new Error(message); };

const publicUser = (user: LocalUser | undefined) => {
  if (!user) return null;
  const { salt: _salt, passwordHash: _hash, ...safe } = user;
  return safe;
};

async function currentData(state: State): Promise<UserData> {
  if (state.session === null) return fail("Sessão expirada. Entre novamente.");
  return state.data[String(state.session)] ?? fail("Workspace não encontrado.");
}

async function ensureDemo(state: State) {
  if (!state.users.some(u => u.id === DEMO_ID)) {
    state.users.push({ id: DEMO_ID, openId: "demo-local", name: "Marina Costa", email: DEMO_EMAIL, loginMethod: "password", role: "admin", status: "active", salt: null, passwordHash: null, createdAt: new Date().toISOString(), lastSignedIn: new Date().toISOString() });
  }
  if (!state.data[String(DEMO_ID)]) state.data[String(DEMO_ID)] = seedWorkspace({ workspaceName: "Centrall Studio", userName: "Marina Costa", isDemo: true });
}

/* ---------- "Servidor" local: mesmas operações que existiam no tRPC ---------- */

type Input = any;

export const handlers: Record<string, (input: Input) => Promise<unknown>> = {
  "auth.me": async () => {
    const state = await getState();
    return publicUser(state.users.find(u => u.id === state.session));
  },

  "auth.demo": async () => {
    const state = await getState();
    await ensureDemo(state);
    state.session = DEMO_ID;
    await save(state);
    return publicUser(state.users.find(u => u.id === DEMO_ID));
  },

  "auth.login": async (input: { email: string; password: string }) => {
    const state = await getState();
    const email = input.email.toLowerCase().trim();
    if (email === DEMO_EMAIL && input.password === DEMO_PASSWORD) return handlers["auth.demo"](undefined);
    const user = state.users.find(u => u.email === email && u.id !== DEMO_ID);
    if (!user?.passwordHash || !user.salt) return fail("E-mail ou senha inválidos.");
    if ((await hashPassword(input.password, user.salt)) !== user.passwordHash) return fail("E-mail ou senha inválidos.");
    user.lastSignedIn = new Date().toISOString();
    state.session = user.id;
    await save(state);
    return publicUser(user);
  },

  "auth.register": async (input: { name: string; email: string; password: string; workspaceName: string }) => {
    const state = await getState();
    const email = input.email.toLowerCase().trim();
    if (input.password.length < 8) return fail("A senha precisa ter pelo menos 8 caracteres.");
    if (state.users.some(u => u.email === email)) return fail("Este e-mail já possui uma conta neste aparelho.");
    const id = state.nextId++;
    const salt = newSalt();
    const user: LocalUser = {
      id, openId: `email_${email}`, name: input.name.trim(), email, loginMethod: "password", role: "admin", status: "active",
      salt, passwordHash: await hashPassword(input.password, salt), createdAt: new Date().toISOString(), lastSignedIn: new Date().toISOString(),
    };
    state.users.push(user);
    state.data[String(id)] = seedWorkspace({ workspaceName: input.workspaceName.trim(), userName: user.name, isDemo: false });
    state.session = id;
    await save(state);
    return publicUser(user);
  },

  "auth.logout": async () => {
    const state = await getState();
    state.session = null;
    await save(state);
    return { success: true };
  },

  "workspace.summary": async () => {
    const state = await getState();
    const data = await currentData(state);
    const stats = data.isDemo
      ? { activeProjects: 8, openTasks: 24, pipelineValue: "R$ 284k", completion: 72 }
      : { activeProjects: 0, openTasks: 0, pipelineValue: "R$ 0", completion: 0 };
    return {
      workspace: data.workspace,
      spaces: data.spaces,
      pages: data.pages.map(({ content: _content, ...rest }) => rest),
      stats,
    };
  },

  "pages.get": async (input: { id: number }) => {
    const data = await currentData(await getState());
    const page = data.pages.find(p => p.id === input.id) ?? data.pages[0];
    return page ?? fail("Página não encontrada.");
  },

  "pages.update": async (input: { id: number; title?: string; content?: Block[] }) => {
    const state = await getState();
    const data = await currentData(state);
    const page = data.pages.find(p => p.id === input.id) ?? fail("Página não encontrada.");
    if (input.title) page.title = input.title;
    if (input.content) {
      page.content = input.content;
      const firstText = input.content.find(b => b.type !== "heading" && b.content)?.content;
      if (firstText) page.excerpt = firstText.slice(0, 140);
    }
    page.updatedAt = nowLabel();
    await save(state);
    return { success: true };
  },

  "pages.create": async (input: { spaceId: number; parentId?: number | null; title?: string }) => {
    const state = await getState();
    const data = await currentData(state);
    const id = state.nextId++;
    const title = input.title?.trim() || "Nova página";
    data.pages.push({
      id, spaceId: input.spaceId, parentId: input.parentId ?? null, title, icon: "✎", color: "#0E7490", type: "page",
      updatedAt: "Agora", excerpt: "Uma nova página para tirar ideias do papel.",
      content: [{ id: "first", type: "paragraph", content: "Comece a escrever…" }],
    });
    await save(state);
    return { id, spaceId: input.spaceId, parentId: input.parentId ?? null, title, icon: "✎", color: "#0E7490" };
  },

  "search.query": async (input: { term: string; spaceId?: number }) => {
    const data = await currentData(await getState());
    const term = input.term.toLowerCase();
    return data.pages
      .filter(p => (!input.spaceId || p.spaceId === input.spaceId) && `${p.title} ${p.excerpt} ${p.content.map(b => b.content ?? "").join(" ")}`.toLowerCase().includes(term))
      .slice(0, 20);
  },
};

/* ---------- Backup: exportar e importar ---------- */

export async function exportBackup() {
  const state = await getState();
  const blob = new Blob([JSON.stringify({ app: "centrall", exportedAt: new Date().toISOString(), state }, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `centrall-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function importBackup(file: File) {
  let parsed: any;
  try {
    parsed = JSON.parse(await file.text());
  } catch {
    return fail("Esse arquivo não é um backup válido.");
  }
  const incoming = parsed?.state;
  if (parsed?.app !== "centrall" || !incoming || incoming.version !== 1 || !Array.isArray(incoming.users) || typeof incoming.data !== "object") {
    return fail("Esse arquivo não é um backup do Centrall.");
  }
  await save(incoming as State);
  statePromise = Promise.resolve(incoming as State);
}
