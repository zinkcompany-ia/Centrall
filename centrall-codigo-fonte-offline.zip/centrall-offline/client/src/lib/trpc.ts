/**
 * Camada de compatibilidade: mantém a mesma API do tRPC usada pelo App
 * (trpc.x.y.useQuery / useMutation / useUtils), mas executa tudo no
 * banco de dados local do aparelho, sem servidor e sem internet.
 */
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { handlers } from "./localdb";

function run(name: string, input: unknown) {
  const handler = handlers[name];
  if (!handler) return Promise.reject(new Error(`Operação desconhecida: ${name}`));
  return handler(input);
}

function procedure(path: string[]): any {
  const name = path.join(".");
  return new Proxy(() => undefined, {
    get(_target, prop: string) {
      if (prop === "useQuery") {
        return (input?: unknown, options?: Record<string, unknown>) =>
          useQuery({ queryKey: [name, input ?? null], queryFn: () => run(name, input), ...options });
      }
      if (prop === "useMutation") {
        return (options?: Record<string, unknown>) =>
          useMutation({ mutationFn: (input?: unknown) => run(name, input), ...options });
      }
      return procedure([...path, prop]);
    },
  });
}

function utilsProxy(client: QueryClient, path: string[]): any {
  const name = path.join(".");
  return new Proxy(() => undefined, {
    get(_target, prop: string) {
      if (prop === "invalidate") return (input?: unknown) => client.invalidateQueries({ queryKey: input === undefined ? [name] : [name, input] });
      if (prop === "refetch") return (input?: unknown) => client.refetchQueries({ queryKey: input === undefined ? [name] : [name, input] });
      if (prop === "setData") return (input: unknown, data: unknown) => client.setQueryData([name, input ?? null], data);
      return utilsProxy(client, [...path, prop]);
    },
  });
}

export const trpc: any = new Proxy({}, {
  get(_target, prop: string) {
    if (prop === "useUtils" || prop === "useContext") return () => utilsProxy(useQueryClient(), []);
    return procedure([prop]);
  },
});
