import { parse } from "cookie";
import { jwtVerify, SignJWT } from "jose";
import type { Request, Response } from "express";
import type { User } from "../../drizzle/schema";
import { getDb, getUserById } from "../db";
import { ENV } from "./env";
import { COOKIE_NAME } from "@shared/const";

export const NEXORA_COOKIE = COOKIE_NAME;
const SESSION_DAYS = 14;

export const DEMO_USER = {
  id: -1,
  openId: "demo-nexora",
  name: "Marina Costa",
  email: "demo@centrall.local",
  loginMethod: "password",
  role: "admin",
  passwordHash: null,
  status: "active",
  failedLoginCount: 0,
  lockedUntil: null,
  createdAt: new Date("2025-01-12T09:00:00Z"),
  updatedAt: new Date("2026-09-30T15:10:00Z"),
  lastSignedIn: new Date("2026-09-30T15:10:00Z"),
} as unknown as User;

export const DEMO_WORKSPACE = {
  id: -1,
  slug: "centrall-studio",
  name: "Centrall Studio",
  initials: "CS",
  accentColor: "#0E7490",
};

export const DEMO_SPACES = [
  { id: -11, name: "Início", icon: "⌂", color: "#0E7490", isPersonal: false },
  { id: -12, name: "Comercial", icon: "↗", color: "#D97706", isPersonal: false },
  { id: -13, name: "Operações", icon: "◒", color: "#7C3AED", isPersonal: false },
  { id: -14, name: "Pessoas", icon: "✦", color: "#DB2777", isPersonal: false },
  { id: -15, name: "Financeiro", icon: "⌁", color: "#059669", isPersonal: false },
  { id: -16, name: "Pessoal", icon: "○", color: "#64748B", isPersonal: true },
];

export const DEMO_PAGES = [
  { id: -101, spaceId: -11, parentId: null, title: "Visão geral", icon: "⌂", color: "#0E7490", type: "home", updatedAt: "Hoje, 09:42", excerpt: "Tudo o que está acontecendo na Centrall Studio, em um só lugar." },
  { id: -102, spaceId: -11, parentId: null, title: "Comunicados", icon: "◈", color: "#0E7490", type: "page", updatedAt: "Ontem, 16:20", excerpt: "Atualizações e decisões que movem a empresa." },
  { id: -103, spaceId: -12, parentId: null, title: "Pipeline comercial", icon: "▱", color: "#D97706", type: "database", updatedAt: "Hoje, 08:15", excerpt: "Negócios ativos, próximos passos e forecast." },
  { id: -104, spaceId: -12, parentId: null, title: "Playbook de vendas", icon: "✎", color: "#D97706", type: "page", updatedAt: "25 set, 14:05", excerpt: "O jeito Orbe de transformar conversas em clientes." },
  { id: -105, spaceId: -13, parentId: null, title: "Projetos em andamento", icon: "◌", color: "#7C3AED", type: "database", updatedAt: "Hoje, 10:05", excerpt: "Sprints, responsáveis e marcos do trimestre." },
  { id: -106, spaceId: -13, parentId: -105, title: "Ritual semanal", icon: "◷", color: "#7C3AED", type: "page", updatedAt: "Hoje, 09:30", excerpt: "Pauta e próximos passos da operação." },
  { id: -107, spaceId: -14, parentId: null, title: "Onboarding de pessoas", icon: "✦", color: "#DB2777", type: "page", updatedAt: "23 set, 11:40", excerpt: "Uma chegada bem cuidada começa antes do primeiro dia." },
  { id: -108, spaceId: -15, parentId: null, title: "Orçamento Q4", icon: "⌁", color: "#059669", type: "page", updatedAt: "20 set, 17:20", excerpt: "Metas, projeções e compromissos financeiros." },
];

export async function createSessionToken(payload: { userId: number; email: string; demo?: boolean }) {
  const secret = new TextEncoder().encode(ENV.cookieSecret || process.env.NEXORA_SESSION_SECRET || "nexora-preview-secret");
  return new SignJWT({ uid: String(payload.userId), email: payload.email, demo: Boolean(payload.demo) })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(secret);
}

export function setSessionCookie(res: Response, token: string) {
  res.cookie(NEXORA_COOKIE, token, {
    httpOnly: true,
    secure: true,
    sameSite: "none",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000,
  });
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(NEXORA_COOKIE, { httpOnly: true, secure: true, sameSite: "none", path: "/", maxAge: -1 });
}

export async function authenticateNexoraRequest(req: Request): Promise<User | null> {
  const token = parse(req.headers.cookie ?? "")[NEXORA_COOKIE];
  if (!token) return null;
  try {
    const secret = new TextEncoder().encode(ENV.cookieSecret || process.env.NEXORA_SESSION_SECRET || "nexora-preview-secret");
    const { payload } = await jwtVerify(token, secret, { algorithms: ["HS256"] });
    const uid = Number(payload.uid);
    if (payload.demo || uid === -1) return DEMO_USER;
    const db = await getDb();
    if (!db || !Number.isFinite(uid)) return null;
    return (await getUserById(uid)) ?? null;
  } catch {
    return null;
  }
}

export function publicUser(user: User | null) {
  if (!user) return null;
  const { passwordHash: _passwordHash, failedLoginCount: _failedLoginCount, lockedUntil: _lockedUntil, ...safe } = user as User & Record<string, unknown>;
  return safe;
}
