import { and, asc, desc, eq, like, or } from "drizzle-orm";
import { compare, hash } from "bcryptjs";
import { z } from "zod";
import { getDb, getUserByEmail } from "./db";
import { pages, spaces, users, workspaceMembers, workspaces } from "../drizzle/schema";
import { DEMO_PAGES, DEMO_SPACES, DEMO_USER, DEMO_WORKSPACE, createSessionToken, publicUser, setSessionCookie, clearSessionCookie } from "./_core/nexoraAuth";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";

const blockSchema = z.object({
  id: z.string(),
  type: z.string(),
  content: z.string().optional(),
  checked: z.boolean().optional(),
  language: z.string().optional(),
});

const demoContent: Record<number, z.infer<typeof blockSchema>[]> = {
  [-101]: [
    { id: "b1", type: "heading", content: "Bom dia, Marina" },
    { id: "b2", type: "paragraph", content: "Aqui está o pulso da Centrall Studio. O trabalho importante, sem o ruído." },
    { id: "b3", type: "callout", content: "Hoje é um bom dia para transformar intenção em movimento." },
  ],
  [-103]: [
    { id: "b4", type: "heading", content: "Pipeline comercial" },
    { id: "b5", type: "paragraph", content: "Uma visão compartilhada do que está avançando, travando e pedindo atenção." },
  ],
  [-105]: [
    { id: "b6", type: "heading", content: "Projetos em andamento" },
    { id: "b7", type: "paragraph", content: "Sprints do trimestre com clareza sobre responsáveis, prazos e próximos passos." },
  ],
};

function isDemo(ctxUser: typeof DEMO_USER | null) {
  return ctxUser?.id === -1;
}

async function getAuthorizedPage(userId: number, pageId: number) {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
  const result = await db.select().from(pages).where(and(eq(pages.id, pageId), eq(pages.isArchived, false))).limit(1);
  const page = result[0];
  if (!page) throw new TRPCError({ code: "NOT_FOUND", message: "Página não encontrada." });
  const member = await db.select().from(workspaceMembers).where(and(eq(workspaceMembers.workspaceId, page.workspaceId), eq(workspaceMembers.userId, userId))).limit(1);
  if (!member[0]) throw new TRPCError({ code: "FORBIDDEN", message: "Você não tem acesso a esta página." });
  return { db, page };
}

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(({ ctx }) => publicUser(ctx.user)),
    demo: publicProcedure.mutation(async ({ ctx }) => {
      if (process.env.NODE_ENV === "production" && process.env.NEXORA_DEMO_MODE !== "true") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Demonstração indisponível neste ambiente." });
      }
      setSessionCookie(ctx.res, await createSessionToken({ userId: -1, email: DEMO_USER.email ?? "demo@centrall.local", demo: true }));
      return publicUser(DEMO_USER);
    }),
    login: publicProcedure.input(z.object({ email: z.string().email(), password: z.string().min(8) })).mutation(async ({ input, ctx }) => {
      const normalized = input.email.toLowerCase().trim();
      if (normalized === "demo@centrall.local" && input.password === "Nexora2026!") {
        setSessionCookie(ctx.res, await createSessionToken({ userId: -1, email: normalized, demo: true }));
        return publicUser(DEMO_USER);
      }
      const user = await getUserByEmail(normalized);
      if (!user?.passwordHash || user.status !== "active") throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos." });
      if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Conta temporariamente bloqueada. Tente novamente mais tarde." });
      const valid = await compare(input.password, user.passwordHash);
      if (!valid) throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos." });
      setSessionCookie(ctx.res, await createSessionToken({ userId: user.id, email: normalized }));
      return publicUser(user);
    }),
    register: publicProcedure.input(z.object({ name: z.string().min(2).max(120), email: z.string().email(), password: z.string().min(8).max(72), workspaceName: z.string().min(2).max(120) })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
      const normalized = input.email.toLowerCase().trim();
      const existing = await getUserByEmail(normalized);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Este e-mail já possui uma conta." });
      const passwordHash = await hash(input.password, 12);
      const userInsert = await db.insert(users).values({ openId: `email_${normalized}`, name: input.name.trim(), email: normalized, loginMethod: "password", role: "admin", passwordHash, status: "active" }).$returningId();
      const userId = userInsert[0]?.id;
      if (!userId) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível criar a conta." });
      const slug = input.workspaceName.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70) || `agencia-${userId}`;
      const workspaceInsert = await db.insert(workspaces).values({ slug: `${slug}-${userId}`, name: input.workspaceName.trim(), initials: input.workspaceName.trim().split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase(), accentColor: "#0E7490", createdBy: userId }).$returningId();
      const workspaceId = workspaceInsert[0]?.id;
      if (!workspaceId) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível criar o workspace." });
      await db.insert(workspaceMembers).values({ workspaceId, userId, role: "owner" });
      await db.insert(spaces).values({ workspaceId, name: "Projetos", slug: "projetos", icon: "◌", color: "#7C3AED", sortOrder: 0 });
      await db.insert(spaces).values({ workspaceId, name: "Clientes", slug: "clientes", icon: "↗", color: "#D97706", sortOrder: 1 });
      setSessionCookie(ctx.res, await createSessionToken({ userId, email: normalized }));
      return publicUser(await getUserByEmail(normalized) ?? null);
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      clearSessionCookie(ctx.res);
      return { success: true };
    }),
  }),
  workspace: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      if (isDemo(ctx.user as typeof DEMO_USER)) return { workspace: DEMO_WORKSPACE, spaces: DEMO_SPACES, pages: DEMO_PAGES, stats: { activeProjects: 8, openTasks: 24, pipelineValue: "R$ 284k", completion: 72 } };
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
      const member = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, ctx.user.id)).limit(1);
      if (!member[0]) throw new TRPCError({ code: "FORBIDDEN", message: "Você ainda não pertence a um workspace." });
      const workspace = await db.select().from(workspaces).where(eq(workspaces.id, member[0].workspaceId)).limit(1);
      const dbSpaces = await db.select().from(spaces).where(eq(spaces.workspaceId, member[0].workspaceId)).orderBy(asc(spaces.sortOrder));
      const dbPages = await db.select().from(pages).where(and(eq(pages.workspaceId, member[0].workspaceId), eq(pages.isArchived, false))).orderBy(asc(pages.sortOrder));
      return { workspace: workspace[0], spaces: dbSpaces, pages: dbPages, stats: { activeProjects: 0, openTasks: 0, pipelineValue: "R$ 0", completion: 0 } };
    }),
  }),
  pages: router({
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input, ctx }) => {
      if (isDemo(ctx.user as typeof DEMO_USER)) {
        const page = DEMO_PAGES.find(item => item.id === input.id) ?? DEMO_PAGES[0];
        return { ...page, content: demoContent[input.id] ?? [{ id: `intro-${input.id}`, type: "heading", content: page.title }, { id: `copy-${input.id}`, type: "paragraph", content: page.excerpt }] };
      }
      const { page } = await getAuthorizedPage(ctx.user.id, input.id);
      return page;
    }),
    update: protectedProcedure.input(z.object({ id: z.number(), title: z.string().min(1).max(240).optional(), content: z.array(blockSchema).optional() })).mutation(async ({ input, ctx }) => {
      if (isDemo(ctx.user as typeof DEMO_USER)) return { success: true, ...input };
      const { db } = await getAuthorizedPage(ctx.user.id, input.id);
      await db.update(pages).set({ ...(input.title ? { title: input.title } : {}), ...(input.content ? { content: input.content } : {}), updatedBy: ctx.user.id, updatedAt: new Date() }).where(eq(pages.id, input.id));
      return { success: true };
    }),
    create: protectedProcedure.input(z.object({ spaceId: z.number(), parentId: z.number().nullable().optional(), title: z.string().min(1).max(240).default("Nova página") })).mutation(async ({ input, ctx }) => {
      if (isDemo(ctx.user as typeof DEMO_USER)) return { id: -Date.now(), ...input, icon: "✎", color: "#0E7490" };
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
      const member = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, ctx.user.id)).limit(1);
      if (!member[0]) throw new TRPCError({ code: "FORBIDDEN", message: "Sem workspace." });
      const inserted = await db.insert(pages).values({ workspaceId: member[0].workspaceId, spaceId: input.spaceId, parentId: input.parentId ?? null, title: input.title, icon: "✎", color: "#0E7490", pageType: "page", content: [{ id: "first", type: "paragraph", content: "Comece a escrever…" }], createdBy: ctx.user.id, updatedBy: ctx.user.id }).$returningId();
      return { id: inserted[0]?.id ?? 0, ...input };
    }),
  }),
  search: router({
    query: protectedProcedure.input(z.object({ term: z.string().min(1), spaceId: z.number().optional() })).query(async ({ input, ctx }) => {
      const term = input.term.toLowerCase();
      if (isDemo(ctx.user as typeof DEMO_USER)) return DEMO_PAGES.filter(page => `${page.title} ${page.excerpt}`.toLowerCase().includes(term) && (!input.spaceId || page.spaceId === input.spaceId));
      const db = await getDb();
      if (!db) return [];
      const member = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, ctx.user.id)).limit(1);
      if (!member[0]) return [];
      return db.select().from(pages).where(and(eq(pages.workspaceId, member[0].workspaceId), eq(pages.isArchived, false), input.spaceId ? eq(pages.spaceId, input.spaceId) : undefined, or(like(pages.title, `%${input.term}%`), like(pages.content, `%${input.term}%`)))).orderBy(desc(pages.updatedAt)).limit(20);
    }),
  }),
});

export type AppRouter = typeof appRouter;
