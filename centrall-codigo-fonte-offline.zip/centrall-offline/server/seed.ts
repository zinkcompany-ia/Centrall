import "dotenv/config";
import { hash } from "bcryptjs";
import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { pages, spaces, users, workspaceMembers, workspaces } from "../drizzle/schema";

const pageBlocks = (title: string, paragraph: string) => [
  { id: `${title}-heading`, type: "heading", content: title },
  { id: `${title}-copy`, type: "paragraph", content: paragraph },
  { id: `${title}-callout`, type: "callout", content: "Mantenha este espaço vivo: decisões claras, próximos passos visíveis." },
];

async function seed() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL não configurada");
  const passwordHash = await hash(process.env.NEXORA_SEED_PASSWORD || "Nexora2026!", 12);
  const existingUser = (await db.select().from(users).where(eq(users.email, "marina@orbelabs.com")).limit(1))[0];
  let userId = existingUser?.id;
  if (!userId) {
    const inserted = await db.insert(users).values({ openId: "orbe-marina-costa", name: "Marina Costa", email: "marina@orbelabs.com", loginMethod: "password", role: "admin", passwordHash, status: "active" }).$returningId();
    userId = inserted[0]?.id;
  }
  if (!userId) throw new Error("Não foi possível criar o usuário seed");
  const existingWorkspace = (await db.select().from(workspaces).where(eq(workspaces.slug, "centrall-studio")).limit(1))[0];
  let workspaceId = existingWorkspace?.id;
  if (!workspaceId) {
    const inserted = await db.insert(workspaces).values({ slug: "centrall-studio", name: "Centrall Studio", initials: "OL", accentColor: "#0E7490", createdBy: userId }).$returningId();
    workspaceId = inserted[0]?.id;
  }
  if (!workspaceId) throw new Error("Não foi possível criar o workspace seed");
  const member = await db.select().from(workspaceMembers).where(eq(workspaceMembers.userId, userId)).limit(1);
  if (!member[0]) await db.insert(workspaceMembers).values({ workspaceId, userId, role: "owner" });
  const seedSpaces = [
    ["inicio", "Início", "⌂", "#0E7490", false], ["comercial", "Comercial", "↗", "#D97706", false], ["operacoes", "Operações", "◒", "#7C3AED", false], ["pessoas", "Pessoas", "✦", "#DB2777", false], ["financeiro", "Financeiro", "⌁", "#059669", false], ["pessoal", "Pessoal", "○", "#64748B", true],
  ] as const;
  const spaceIds = new Map<string, number>();
  for (const [slug, name, icon, color, isPersonal] of seedSpaces) {
    const existing = (await db.select().from(spaces).where(eq(spaces.slug, slug)).limit(1))[0];
    const id = existing?.id ?? (await db.insert(spaces).values({ workspaceId, name, slug, icon, color, isPersonal, sortOrder: seedSpaces.findIndex(item => item[0] === slug) }).$returningId())[0]?.id;
    if (id) spaceIds.set(slug, id);
  }
  const seedPages = [
    ["inicio", "Visão geral", "⌂", "home", "Tudo o que está acontecendo na Centrall Studio, em um só lugar."], ["inicio", "Comunicados", "◈", "page", "Atualizações e decisões que movem a empresa."], ["comercial", "Pipeline comercial", "▱", "database", "Negócios ativos, próximos passos e forecast."], ["comercial", "Playbook de vendas", "✎", "page", "O jeito Orbe de transformar conversas em clientes."], ["operacoes", "Projetos em andamento", "◌", "database", "Sprints, responsáveis e marcos do trimestre."], ["pessoas", "Onboarding de pessoas", "✦", "page", "Uma chegada bem cuidada começa antes do primeiro dia."], ["financeiro", "Orçamento Q4", "⌁", "page", "Metas, projeções e compromissos financeiros."],
  ] as const;
  for (const [spaceSlug, title, icon, pageType, paragraph] of seedPages) {
    const spaceId = spaceIds.get(spaceSlug);
    if (!spaceId) continue;
    const exists = (await db.select().from(pages).where(eq(pages.title, title)).limit(1))[0];
    if (!exists) await db.insert(pages).values({ workspaceId, spaceId, title, icon, color: seedSpaces.find(item => item[0] === spaceSlug)?.[3] ?? "#0E7490", pageType, content: pageBlocks(title, paragraph), createdBy: userId, updatedBy: userId });
  }
  console.log(`Seed Centrall concluído: ${workspaceId}`);
  process.exit(0);
}

seed().catch(error => { console.error(error); process.exitCode = 1; });
